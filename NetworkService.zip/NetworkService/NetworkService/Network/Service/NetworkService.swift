//
//  NetworkService.swift
//  Project2
//
//  Created by Sheikh Ahmed on 17/05/2020.
//  Copyright © 2020 Sheikh Ahmed. All rights reserved.
//
import Foundation

public protocol NetworkServiceTypes: class {
    func authenticateUser(userName: String, password: String, completion: @escaping (Result<Bool, APIError>)->Void)
}
public class NetworkService: NetworkServiceTypes{
    public init(){
        
    }
    public func authenticateUser(userName: String, password: String, completion: @escaping (Result<Bool, APIError>)->Void){
        if userName == "user" && password == "password" {
            completion(.success(true))
            UserDefaults.standard.setAuthencationStatus(value: true)
        } else {
            completion(.failure(.unauthorized))
            UserDefaults.standard.setAuthencationStatus(value: true)
        }
    }
}
