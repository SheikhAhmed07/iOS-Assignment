//
//  UserDefaults.swift
//  Project2
//
//  Created by Sheikh Ahmed on 17/05/2020.
//  Copyright © 2020 Sheikh Ahmed. All rights reserved.
//

import Foundation

public enum UserDefaultsKeys: String{
    case authentication
}

extension UserDefaults {
    public func getAuthenticationStatus()->Bool {
        if let value = self.value(forKey: UserDefaultsKeys.authentication.rawValue) as? Bool {
            return value
        }
        return true
    }
    public func setAuthencationStatus(value: Bool){
        self.set(value, forKey: UserDefaultsKeys.authentication.rawValue)
        synchronize()
        NotificationCenter.default.post(name: .authenticationStatusChanged, object: nil)
    }
}
