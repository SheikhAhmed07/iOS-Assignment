//
//  NetworkService.h
//  NetworkService
//
//  Created by Sheikh Ahmed on 17/05/2020.
//  Copyright © 2020 Sheikh Ahmed. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for NetworkService.
FOUNDATION_EXPORT double NetworkServiceVersionNumber;

//! Project version string for NetworkService.
FOUNDATION_EXPORT const unsigned char NetworkServiceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NetworkService/PublicHeader.h>


