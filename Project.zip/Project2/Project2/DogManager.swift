//
//  DogManager.swift
//  Project2
//
//  Created by Sheikh Ahmed on 17/05/2020.
//  Copyright © 2020 Sheikh Ahmed. All rights reserved.
//

import NetworkService

public enum GlobalConstants: String {
    case production
    case development
}
struct DogModel: Codable {
    let message: [String]?
    let status: String?
}

extension GlobalConstants {
    static let DogBaseAPILink: String = {
        return "https://dog.ceo"
    }()
    static let QuoteAPILink: String = {
        return "https://jsonplaceholder.typicode.com"
    }()
}


import SwiftUI

struct DogResource {
    var numberOfImages: Int
}
extension DogResource: ResourceType {
    var baseURL: URL {
        guard let url = URL(string: GlobalConstants.DogBaseAPILink) else { fatalError("baseURL could not be configured.") }
        return url
    }
    var path: String {
        return "/api/breeds/image/random/\(numberOfImages)"
    }
    var parameter: Parameters {
        let param = [String: String]()
        return param
    }
    var httpMethod: HTTPMethod {
        return .get
    }
    var task: HTTPTask {
        return .requestParametersAndHeaders(bodyParameters: nil, bodyEncoding: .urlEncoding , urlParameters: parameter, additionHeaders: nil)
    }
}

protocol DogServiceType: class {
    func getDogImages(numberOfImages: Int, completion: @escaping(Result<DogModel?, APIError>)->Void)
}

class DogService: DogServiceType {
    var requestManager: RequestManagerType = RequestManager()
    
    func getDogImages(numberOfImages: Int, completion: @escaping (Result<DogModel?, APIError>) -> Void) {
        
        let resource = DogResource(numberOfImages: numberOfImages)
        
        guard let request = try? resource.makeRequest() else { return }
        //print(request.url)
        
        requestManager.fetch(with: request, decode: {
            json -> DogModel? in
            
            guard let model = json as? DogModel else { return nil }
            
            return model
        }, completion: completion)
    }
    
    
}

