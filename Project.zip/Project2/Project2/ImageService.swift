//
//  ImageService.swift
//  Project1
//
//  Created by Sheikh Ahmed on 17/05/2020.
//  Copyright © 2020 Sheikh Ahmed. All rights reserved.
//

import UIKit
import Kingfisher

protocol ImageServiceType {
    func retrieveImage(withLink: String, completion: @escaping (UIImage?) -> Void)
    func retrieveImage(withURL: URL, completion: @escaping (UIImage?) -> Void)
    func clearCaches()
}

class ImageService: ImageServiceType {
    static let shared: ImageServiceType = ImageService()
    
    private init() {
        // Private init for singleton
    }
    
    func retrieveImage(withLink link: String, completion: @escaping (UIImage?) -> Void) {
        guard let imageURL = URL(string: link) else {
            completion(nil)
            return
        }
        
        retrieveImage(withURL: imageURL, completion: completion)
    }
     
    func retrieveImage(withURL imageURL: URL, completion: @escaping (UIImage?) -> Void) {
        KingfisherManager.shared.retrieveImage(with: imageURL) { (result) in
            switch result {
            case .success(let retrieveImageResult):
                completion(retrieveImageResult.image)
            case .failure:
                completion(nil)
            }
        }
    }
    
    func clearCaches() {
        KingfisherManager.shared.cache.clearMemoryCache()
        KingfisherManager.shared.cache.clearDiskCache()
        KingfisherManager.shared.cache.cleanExpiredDiskCache()
    }
}


