//
//  ImageTableViewCell.swift
//  Project2
//
//  Created by Sheikh Ahmed on 17/05/2020.
//  Copyright © 2020 Sheikh Ahmed. All rights reserved.
//

import UIKit

class ImageTableViewCell: UITableViewCell, NibBased {
    let imageService = ImageService.shared
    @IBOutlet weak var dogImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
    }
    func setImage(imageURL: String){
        imageService.retrieveImage(withLink: imageURL) { (uiImage) in
            if let image = uiImage {
                self.dogImage.image = image
            }
        }
    }
    
}
