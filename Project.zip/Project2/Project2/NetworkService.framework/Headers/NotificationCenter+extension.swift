//
//  NotificationCenter+extension.swift
//  Project2
//
//  Created by Sheikh Ahmed on 17/05/2020.
//  Copyright © 2020 Sheikh Ahmed. All rights reserved.
//

import Foundation
public enum NotificationNames: String{
    case authenticationChanged
}
extension Notification.Name {
    public static let authenticationStatusChanged = Notification.Name(NotificationNames.authenticationChanged.rawValue)
}
