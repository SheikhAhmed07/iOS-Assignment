
import UIKit

public protocol NibBased {
    static var nibName: String { get }
}

extension NibBased {
    static var nibName: String {
        return String(describing: self)
    }
    static var nib: UINib? {
        return UINib(nibName: nibName, bundle: nil)
    }
}
