//
//  ViewController.swift
//  Project2
//
//  Created by Sheikh Ahmed on 17/05/2020.
//  Copyright © 2020 Sheikh Ahmed. All rights reserved.
//

import UIKit
import NetworkService

class ViewController: UIViewController {
    var networkService = NetworkService()
    var imageQueue1: Int = 0 {
        didSet{
            print("current item in queue 1: \(imageQueue1)")
        }
    }
    var imageQueue2: Int = 0 {
        didSet{
            print("current item in queue 2: \(imageQueue2)")
        }
    }
    
    var tableData1: [String] = [] {
        didSet {
            print("Image loaded to Queue 1")
        }
    }
    
    var tableData2: [String] = [] {
        didSet {
            print("Image loaded to Queue 2")
        }
    }
    
    @IBOutlet weak var loginState: UISwitch!
    
    @IBOutlet weak var loadTwo: UIButton!
    @IBOutlet weak var tableView1: UITableView!
    
    
    @IBOutlet weak var loadMoreTwo: UIButton!
    @IBOutlet weak var tableView2: UITableView!
    
    @IBAction func loadTwoPressed(_ sender: UIButton) {
        if UserDefaults.standard.getAuthenticationStatus() {
            self.perFormImageQueue1()
        } else {
            imageQueue1 += 1
        }
    }
    @IBAction func loadMoreTwoPressed(_ sender: UIButton) {
        if UserDefaults.standard.getAuthenticationStatus() {
            self.perFormImageQueue2()
        } else {
            imageQueue2 += 1
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UserDefaults.standard.setAuthencationStatus(value: false)
        self.loginState.addTarget(self, action: #selector(switchChanged(loginState:)), for: .valueChanged)
        NotificationCenter.default.addObserver(self, selector: #selector(performImageQueue), name: .authenticationStatusChanged, object: nil)
        setupTableView()
    }
    @objc func switchChanged(loginState: UISwitch){
        switch loginState.isOn{
        case true:
            networkService.authenticateUser(userName: "user", password: "password") { (result) in
                switch result{
                case .success(let value):
                    if value{
                        print("Log in successful")
                    } else {
                        print("Log in unsuccessful")
                    }
                case .failure(let error):
                    print("Error \(error.localizedDescription)")
                }
                
            }
        case false:
            UserDefaults.standard.setAuthencationStatus(value: false)
        }
    }
    
    @objc func performImageQueue(){
        if imageQueue1 > 0 {
            perFormImageQueue1()
        }
        if imageQueue2 > 0 {
            perFormImageQueue2()
        }
    }
    
    func setupTableView(){
        tableView1.dataSource = self
        tableView1.delegate = self
        tableView1.tableFooterView = UIView()
        tableView1.register(ImageTableViewCell.self)
        tableView2.dataSource = self
        tableView2.delegate = self
        tableView2.register(ImageTableViewCell.self)
        tableView2.tableFooterView = UIView()
    }
    
    
    func perFormImageQueue1(){
        // guard imageQueue1 > 0 else { return}
        let dogService = DogService()
        dogService.getDogImages(numberOfImages: imageQueue1) { (result) in
            switch result{
            case .success(let model):
                if let model = model, model.status == "success"{
                    if let messages = model.message {
                        self.tableData1.append(contentsOf: messages)
                        self.imageQueue1 = 0
                        self.tableView1.reloadData()
                    }
                }
            case .failure(let error):
                print("API error occured for Queue 1: \(error.localizedDescription)")
            }
        }
    }
    func perFormImageQueue2(){
        //      guard imageQueue2 > 0 else { return}
        let dogService = DogService()
        dogService.getDogImages(numberOfImages: imageQueue2) { (result) in
            switch result{
            case .success(let model):
                if let model = model, model.status == "success"{
                    if let messages = model.message {
                        self.tableData2.append(contentsOf: messages)
                        self.imageQueue2 = 0
                        self.tableView2.reloadData()
                    }
                }
            case .failure(let error):
                print("API error occured for Queue 2: \(error.localizedDescription)")
            }
        }
    }
    
}

extension ViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch tableView {
        case self.tableView1:
            return tableData1.count
        case self.tableView2:
            return tableData2.count
        default :
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = UITableViewCell()
        switch tableView {
        case self.tableView1:
            let imageCell1: ImageTableViewCell = tableView.dequeueReusableCell(for: indexPath)
            if indexPath.row < tableData1.count{
                imageCell1.setImage(imageURL: tableData1[indexPath.row])
            }
            cell = imageCell1
        case self.tableView2:
            let imageCell2: ImageTableViewCell = tableView.dequeueReusableCell(for: indexPath)
            if indexPath.row < tableData2.count {
                imageCell2.setImage(imageURL: tableData2[indexPath.row])
            }
            cell = imageCell2
        default :
            break
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
}
extension ViewController: UITableViewDelegate {
    
}
